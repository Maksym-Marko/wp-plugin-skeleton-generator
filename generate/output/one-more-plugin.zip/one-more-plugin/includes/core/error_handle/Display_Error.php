<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Error Handle calss
*/
class MXOMP_Display_Error
{

	/**
	* Error notice
	*/
	public $mxomp_error_notice = '';

	public function __construct( $mxomp_error_notice )
	{

		$this->mxomp_error_notice = $mxomp_error_notice;

	}

	public function mxomp_show_error()
	{
		add_action( 'admin_notices', function() { ?>

			<div class="notice notice-error is-dismissible">

			    <p><?php echo esc_attr( $this->mxomp_error_notice ); ?></p>
			    
			</div>
		    
		<?php } );
	}

}