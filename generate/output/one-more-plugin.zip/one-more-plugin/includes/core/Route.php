<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXOMP_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXOMP_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxomp_get( ...$args )
	{

		return new MXOMP_Route_Registrar( ...$args );

	}
	
}