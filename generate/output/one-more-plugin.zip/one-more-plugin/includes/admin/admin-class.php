<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXOMP_Admin_Main
{

	// list of model names used in the plugin
	public $models_collection = [
		'MXOMP_Main_Page_Model'
	];

	/*
	* MXOMP_Admin_Main constructor
	*/
	public function __construct()
	{

	}

	/*
	* Additional classes
	*/
	public function mxomp_additional_classes()
	{

		// enqueue_scripts class
		mxomp_require_class_file_admin( 'enqueue-scripts.php' );

		MXOMP_Enqueue_Scripts::mxomp_register();

		// mx metaboxes class
		mxomp_require_class_file_admin( 'metabox.php' );

		mxomp_require_class_file_admin( 'metabox-image-upload.php' );

		MXOMP_Metaboxes_Image_Upload_Class::register_scrips();
		
		// CPT class
		mxomp_require_class_file_admin( 'cpt.php' );

		MXOMPCPTclass::createCPT();

	}

	/*
	* Models Connection
	*/
	public function mxomp_models_collection()
	{

		// require model file
		foreach ( $this->models_collection as $model ) {
			
			mxomp_use_model( $model );

		}		

	}

	/**
	* registration ajax actions
	*/
	public function mxomp_registration_ajax_actions()
	{

		// ajax requests to main page
		MXOMP_Main_Page_Model::mxomp_wp_ajax();

	}

	/*
	* Routes collection
	*/
	public function mxomp_routes_collection()
	{

		// main menu item
		MXOMP_Route::mxomp_get( 'MXOMP_Main_Page_Controller', 'index', '', [
			'page_title' => 'Main Menu title',
			'menu_title' => 'Main menu'
		] );

		// sub menu item
		MXOMP_Route::mxomp_get( 'MXOMP_Main_Page_Controller', 'submenu', '', [
			'page_title' => 'Sub Menu title',
			'menu_title' => 'Sub menu'
		], 'sub_menu' );

		// hide menu item
		MXOMP_Route::mxomp_get( 'MXOMP_Main_Page_Controller', 'hidemenu', 'NULL', [
			'page_title' => 'Hidden Menu title',
		], 'hide_menu' );

		// sub settings menu item
		MXOMP_Route::mxomp_get( 'MXOMP_Main_Page_Controller', 'settings_menu_item_action', 'NULL', [
			'menu_title' => 'Settings Item',
			'page_title' => 'Title of settings page'
		], 'settings_menu_item', true );

	}

}

// Initialize
$initialize_admin_class = new MXOMP_Admin_Main();

// include classes
$initialize_admin_class->mxomp_additional_classes();

// include models
$initialize_admin_class->mxomp_models_collection();

// ajax requests
$initialize_admin_class->mxomp_registration_ajax_actions();

// include controllers
$initialize_admin_class->mxomp_routes_collection();