<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'Settings Page', 'mxomp-domain' ); ?></h1>

	<div class="mx-block_wrap">

		<form id="mxomp_form_update" class="mx-settings" method="post" action="">

			<h2>Default script</h2>
			<textarea name="mxomp_some_string" id="mxomp_some_string"><?php echo $data->mx_name; ?></textarea>

			<p class="mx-submit_button_wrap">
				<input type="hidden" id="mxomp_wpnonce" name="mxomp_wpnonce" value="<?php echo wp_create_nonce( 'mxomp_nonce_request' ) ;?>" />
				<input class="button-primary" type="submit" name="mxomp_submit" value="Save" />
			</p>

		</form>

	</div>

</div>