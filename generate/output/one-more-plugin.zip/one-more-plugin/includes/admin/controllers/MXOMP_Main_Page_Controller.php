<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXOMP_Main_Page_Controller extends MXOMP_Controller
{
	
	public function index()
	{

		$model_inst = new MXOMP_Main_Page_Model();

		$data = $model_inst->mxomp_get_row( NULL, 'product_id', 1 );

		return new MXOMP_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXOMP_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXOMP_View( 'hidemenu-page' );

	}

	public function settings_menu_item_action()
	{

		return new MXOMP_View( 'settings-page' );

	}

}