<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXOMP_Enqueue_Scripts
{

	/*
	* MXOMP_Enqueue_Scripts
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxomp_register()
	{

		// register scripts and styles
		add_action( 'admin_enqueue_scripts', [ 'MXOMP_Enqueue_Scripts', 'mxomp_enqueue' ] );

	}

		public static function mxomp_enqueue()
		{

			wp_enqueue_style( 'mxomp_font_awesome', MXOMP_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );

			wp_enqueue_style( 'mxomp_admin_style', MXOMP_PLUGIN_URL . 'includes/admin/assets/css/style.css', [ 'mxomp_font_awesome' ], MXOMP_PLUGIN_VERSION, 'all' );

			wp_enqueue_script( 'mxomp_admin_script', MXOMP_PLUGIN_URL . 'includes/admin/assets/js/script.js', [ 'jquery' ], MXOMP_PLUGIN_VERSION, false );

			wp_localize_script( 'mxomp_admin_script', 'mxomp_admin_localize', [

				'ajaxurl' 			=> admin_url( 'admin-ajax.php' )

			] );

		}

}