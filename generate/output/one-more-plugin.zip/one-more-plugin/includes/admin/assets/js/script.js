jQuery( document ).ready( function( $ ) {

	$( '#mxomp_form_update' ).on( 'submit', function( e ){

		e.preventDefault();

		var nonce = $( this ).find( '#mxomp_wpnonce' ).val();

		var someString = $( '#mxomp_some_string' ).val();

		var data = {

			'action': 'mxomp_update',
			'nonce': nonce,
			'mxomp_some_string': someString

		};

		jQuery.post( mxomp_admin_localize.ajaxurl, data, function( response ){

			// console.log( response );
			alert( 'Value updated.' );

		} );

	} );

} );