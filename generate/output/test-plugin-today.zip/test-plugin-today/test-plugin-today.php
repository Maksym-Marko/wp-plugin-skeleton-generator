<?php
/*
Plugin Name: Test plugin today
Plugin URI: https://github.com/Maxim-us/wp-plugin-skeleton
Description: Brief description:
Author: Marko Maksym
Version: 1.0
Author URI: https://github.com/Maxim-us
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Unique string - MXTPT
*/

/*
* Define MXTPT_PLUGIN_PATH
*
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\test-plugin-today\test-plugin-today.php
*/
if ( ! defined( 'MXTPT_PLUGIN_PATH' ) ) {

	define( 'MXTPT_PLUGIN_PATH', __FILE__ );

}

/*
* Define MXTPT_PLUGIN_URL
*
* Return http://my-domain.com/wp-content/plugins/test-plugin-today/
*/
if ( ! defined( 'MXTPT_PLUGIN_URL' ) ) {

	define( 'MXTPT_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

}

/*
* Define MXTPT_PLUGN_BASE_NAME
*
* 	Return test-plugin-today/test-plugin-today.php
*/
if ( ! defined( 'MXTPT_PLUGN_BASE_NAME' ) ) {

	define( 'MXTPT_PLUGN_BASE_NAME', plugin_basename( __FILE__ ) );

}

/*
* Define MXTPT_TABLE_SLUG
*/
if ( ! defined( 'MXTPT_TABLE_SLUG' ) ) {

	define( 'MXTPT_TABLE_SLUG', 'mxtpt_table_slug' );

}

/*
* Define MXTPT_PLUGIN_ABS_PATH
* 
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\test-plugin-today/
*/
if ( ! defined( 'MXTPT_PLUGIN_ABS_PATH' ) ) {

	define( 'MXTPT_PLUGIN_ABS_PATH', dirname( MXTPT_PLUGIN_PATH ) . '/' );

}

/*
* Define MXTPT_PLUGIN_VERSION
*/
if ( ! defined( 'MXTPT_PLUGIN_VERSION' ) ) {

	// version
	define( 'MXTPT_PLUGIN_VERSION', time() ); // Must be replaced before production on for example '1.0'

}

/*
* Define MXTPT_MAIN_MENU_SLUG
*/
if ( ! defined( 'MXTPT_MAIN_MENU_SLUG' ) ) {

	// version
	define( 'MXTPT_MAIN_MENU_SLUG', 'mxtpt-test-plugin-today-menu' );

}

/**
 * activation|deactivation
 */
require_once plugin_dir_path( __FILE__ ) . 'install.php';

/*
* Registration hooks
*/
// Activation
register_activation_hook( __FILE__, array( 'MXTPT_Basis_Plugin_Class', 'activate' ) );

// Deactivation
register_deactivation_hook( __FILE__, array( 'MXTPT_Basis_Plugin_Class', 'deactivate' ) );


/*
* Include the main MXTPTTestPluginToday class
*/
if ( ! class_exists( 'MXTPTTestPluginToday' ) ) {

	require_once plugin_dir_path( __FILE__ ) . 'includes/final-class.php';

	/*
	* Translate plugin
	*/
	add_action( 'plugins_loaded', 'mxtpt_translate' );

	function mxtpt_translate()
	{

		load_plugin_textdomain( 'mxtpt-domain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

}