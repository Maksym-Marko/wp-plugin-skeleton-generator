<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPT_Admin_Main
{

	// list of model names used in the plugin
	public $models_collection = [
		'MXTPT_Main_Page_Model'
	];

	/*
	* MXTPT_Admin_Main constructor
	*/
	public function __construct()
	{

	}

	/*
	* Additional classes
	*/
	public function mxtpt_additional_classes()
	{

		// enqueue_scripts class
		mxtpt_require_class_file_admin( 'enqueue-scripts.php' );

		MXTPT_Enqueue_Scripts::mxtpt_register();


		// CPT class
		mxtpt_require_class_file_admin( 'cpt.php' );

		MXTPTCPTclass::createCPT();

	}

	/*
	* Models Connection
	*/
	public function mxtpt_models_collection()
	{

		// require model file
		foreach ( $this->models_collection as $model ) {
			
			mxtpt_use_model( $model );

		}		

	}

	/**
	* registration ajax actions
	*/
	public function mxtpt_registration_ajax_actions()
	{

		// ajax requests to main page
		MXTPT_Main_Page_Model::mxtpt_wp_ajax();

	}

	/*
	* Routes collection
	*/
	public function mxtpt_routes_collection()
	{

		// main menu item
		MXTPT_Route::mxtpt_get( 'MXTPT_Main_Page_Controller', 'index', '', [
			'page_title' => 'Main Menu title',
			'menu_title' => 'Main menu'
		] );

		// sub menu item
		MXTPT_Route::mxtpt_get( 'MXTPT_Main_Page_Controller', 'submenu', '', [
			'page_title' => 'Sub Menu title',
			'menu_title' => 'Sub menu'
		], 'sub_menu' );

		// sub menu item
		MXTPT_Route::mxtpt_get( 'MXTPT_Main_Page_Controller', 'hidemenu', 'NULL', [
			'page_title' => 'Hidden Menu title',
		], 'hide_menu' );

	}

}

// Initialize
$initialize_admin_class = new MXTPT_Admin_Main();

// include classes
$initialize_admin_class->mxtpt_additional_classes();

// include models
$initialize_admin_class->mxtpt_models_collection();

// ajax requests
$initialize_admin_class->mxtpt_registration_ajax_actions();

// include controllers
$initialize_admin_class->mxtpt_routes_collection();