jQuery( document ).ready( function( $ ) {

	$( '#mxtpt_form_update' ).on( 'submit', function( e ){

		e.preventDefault();

		var nonce = $( this ).find( '#mxtpt_wpnonce' ).val();

		var someString = $( '#mxtpt_some_string' ).val();

		var data = {

			'action': 'mxtpt_update',
			'nonce': nonce,
			'mxtpt_some_string': someString

		};

		jQuery.post( mxmlb_admin_localize.ajaxurl, data, function( response ){

			// console.log( response );
			alert( 'Value updated.' );

		} );

	} );

} );