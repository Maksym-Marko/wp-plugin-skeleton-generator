<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPT_Main_Page_Controller extends MXTPT_Controller
{
	
	public function index()
	{

		$model_inst = new MXTPT_Main_Page_Model();

		$data = $model_inst->mxtpt_get_row( NULL, 'id', 1 );

		return new MXTPT_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXTPT_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXTPT_View( 'hidemenu-page' );

	}

}