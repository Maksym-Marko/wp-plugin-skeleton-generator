<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPT_Enqueue_Scripts
{

	/*
	* MXTPT_Enqueue_Scripts
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxtpt_register()
	{

		// register scripts and styles
		add_action( 'admin_enqueue_scripts', array( 'MXTPT_Enqueue_Scripts', 'mxtpt_enqueue' ) );

	}

		public static function mxtpt_enqueue()
		{

			wp_enqueue_style( 'mxtpt_font_awesome', MXTPT_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );

			wp_enqueue_style( 'mxtpt_admin_style', MXTPT_PLUGIN_URL . 'includes/admin/assets/css/style.css', array( 'mxtpt_font_awesome' ), MXTPT_PLUGIN_VERSION, 'all' );

			wp_enqueue_script( 'mxtpt_admin_script', MXTPT_PLUGIN_URL . 'includes/admin/assets/js/script.js', array( 'jquery' ), MXTPT_PLUGIN_VERSION, false );

		}

}