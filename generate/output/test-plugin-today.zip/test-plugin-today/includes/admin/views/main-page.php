<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'Settings Page', 'mxtpt-domain' ); ?></h1>

	<div class="mx-block_wrap">

		<form id="mxtpt_form_update" class="mx-settings" method="post" action="">

			<h2>Default script</h2>
			<textarea name="mxtpt_some_string" id="mxtpt_some_string"><?php echo $data->some_field; ?></textarea>

			<p class="mx-submit_button_wrap">
				<input type="hidden" id="mxtpt_wpnonce" name="mxtpt_wpnonce" value="<?php echo wp_create_nonce( 'mxtpt_nonce_request' ) ;?>" />
				<input class="button-primary" type="submit" name="mxtpt_submit" value="Save" />
			</p>

		</form>

	</div>

</div>