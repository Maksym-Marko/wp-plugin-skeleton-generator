<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Error Handle calss
*/
class MXTPT_Display_Error
{

	/**
	* Error notice
	*/
	public $mxtpt_error_notice = '';

	public function __construct( $mxtpt_error_notice )
	{

		$this->mxtpt_error_notice = $mxtpt_error_notice;

	}

	public function mxtpt_show_error()
	{
		
		add_action( 'admin_notices', function() { ?>

			<div class="notice notice-error is-dismissible">

			    <p><?php echo $this->mxtpt_error_notice; ?></p>
			    
			</div>
		    
		<?php } );

	}

}