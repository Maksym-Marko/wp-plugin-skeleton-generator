<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Error Handle calss
*/
class MXTPT_Error_Handle
{

	/**
	* Error name
	*/
	// public $mxtpt_error_name = '';	

	/**
	* has error
	*/
	public $mxtpt_isnt_error = true;

	public function __construct()
	{

	}
	
	public function mxtpt_class_attributes_error( $class_name, $method )
	{

		// if class not exists display an error
		if( class_exists( $class_name ) ) {

			// check if method exists
			$class_inst = new $class_name();

			// if method not exists display an error
			if( !method_exists( $class_inst, $method ) ) {

				// notice of error
				$mxtpt_error_notice = "The <b>\"{$class_name}\"</b> class doesn't contain the <b>\"{$method}\"</b> method.";

				// show an error
				$error_method_inst = new MXTPT_Display_Error( $mxtpt_error_notice );

				$error_method_inst->mxtpt_show_error();

				$this->mxtpt_isnt_error = $mxtpt_error_notice;

			}

		} else {

			// notice of error
			$mxtpt_error_notice = "The <b>\"{$class_name}\"</b> class not exists.";

			// show an error
			$error_class_inst = new MXTPT_Display_Error( $mxtpt_error_notice );

			$error_class_inst->mxtpt_show_error();

			$this->mxtpt_isnt_error = $mxtpt_error_notice;

		}
	
		// 
		return $this->mxtpt_isnt_error;

	}
	
}