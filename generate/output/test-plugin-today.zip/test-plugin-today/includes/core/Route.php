<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXTPT_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXTPT_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxtpt_get( ...$args )
	{

		return new MXTPT_Route_Registrar( ...$args );

	}
	
}