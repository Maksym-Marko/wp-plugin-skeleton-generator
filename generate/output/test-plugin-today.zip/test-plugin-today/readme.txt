=== Test plugin today ===
Contributors: markomaksym
Tags: buddypress, activity, activity stream, buddypress activity, embed, attach
Requires at least: 4.3
Tested up to: 4.9
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Brief description:

== Description ==

Long description

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'WP Plugin Skeleton'
3. Activate the plugin from your Plugins page.
4. ...

= From WordPress.org =

1. Download 'WP Plugin Skeleton'.
2. Upload the 'WP Plugin Skeleton' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate 'WP Plugin Skeleton' from your Plugins page.
4. ...

== Screenshots ==

1. Click the button
2. Item moved upwards
3. Click the button again
4. ...

== Changelog ==

= 1.0 =
* Your first commit