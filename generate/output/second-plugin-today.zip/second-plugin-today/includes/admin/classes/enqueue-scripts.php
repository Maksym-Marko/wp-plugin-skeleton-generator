<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXSPT_Enqueue_Scripts
{

	/*
	* MXSPT_Enqueue_Scripts
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxspt_register()
	{

		// register scripts and styles
		add_action( 'admin_enqueue_scripts', array( 'MXSPT_Enqueue_Scripts', 'mxspt_enqueue' ) );

	}

		public static function mxspt_enqueue()
		{

			wp_enqueue_style( 'mxspt_font_awesome', MXSPT_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );

			wp_enqueue_style( 'mxspt_admin_style', MXSPT_PLUGIN_URL . 'includes/admin/assets/css/style.css', array( 'mxspt_font_awesome' ), MXSPT_PLUGIN_VERSION, 'all' );

			wp_enqueue_script( 'mxspt_admin_script', MXSPT_PLUGIN_URL . 'includes/admin/assets/js/script.js', array( 'jquery' ), MXSPT_PLUGIN_VERSION, false );

		}

}