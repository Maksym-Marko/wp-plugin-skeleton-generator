<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXSPT_Admin_Main
{

	// list of model names used in the plugin
	public $models_collection = [
		'MXSPT_Main_Page_Model'
	];

	/*
	* MXSPT_Admin_Main constructor
	*/
	public function __construct()
	{

	}

	/*
	* Additional classes
	*/
	public function mxspt_additional_classes()
	{

		// enqueue_scripts class
		mxspt_require_class_file_admin( 'enqueue-scripts.php' );

		MXSPT_Enqueue_Scripts::mxspt_register();


		// CPT class
		mxspt_require_class_file_admin( 'cpt.php' );

		MXSPTCPTclass::createCPT();

	}

	/*
	* Models Connection
	*/
	public function mxspt_models_collection()
	{

		// require model file
		foreach ( $this->models_collection as $model ) {
			
			mxspt_use_model( $model );

		}		

	}

	/**
	* registration ajax actions
	*/
	public function mxspt_registration_ajax_actions()
	{

		// ajax requests to main page
		MXSPT_Main_Page_Model::mxspt_wp_ajax();

	}

	/*
	* Routes collection
	*/
	public function mxspt_routes_collection()
	{

		// main menu item
		MXSPT_Route::mxspt_get( 'MXSPT_Main_Page_Controller', 'index', '', [
			'page_title' => 'Main Menu title',
			'menu_title' => 'Main menu'
		] );

		// sub menu item
		MXSPT_Route::mxspt_get( 'MXSPT_Main_Page_Controller', 'submenu', '', [
			'page_title' => 'Sub Menu title',
			'menu_title' => 'Sub menu'
		], 'sub_menu' );

		// hide menu item
		MXSPT_Route::mxspt_get( 'MXSPT_Main_Page_Controller', 'hidemenu', 'NULL', [
			'page_title' => 'Hidden Menu title',
		], 'hide_menu' );

		// sub settings menu item
		MXSPT_Route::mxspt_get( 'MXSPT_Main_Page_Controller', 'settings_menu_item_action', 'NULL', [
			'menu_title' => 'Settings Item',
			'page_title' => 'Title of settings page'
		], 'settings_menu_item', true );

	}

}

// Initialize
$initialize_admin_class = new MXSPT_Admin_Main();

// include classes
$initialize_admin_class->mxspt_additional_classes();

// include models
$initialize_admin_class->mxspt_models_collection();

// ajax requests
$initialize_admin_class->mxspt_registration_ajax_actions();

// include controllers
$initialize_admin_class->mxspt_routes_collection();