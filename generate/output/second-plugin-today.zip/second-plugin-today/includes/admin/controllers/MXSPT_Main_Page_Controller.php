<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXSPT_Main_Page_Controller extends MXSPT_Controller
{
	
	public function index()
	{

		$model_inst = new MXSPT_Main_Page_Model();

		$data = $model_inst->mxspt_get_row( NULL, 'id', 1 );

		return new MXSPT_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXSPT_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXSPT_View( 'hidemenu-page' );

	}

	public function settings_menu_item_action()
	{

		return new MXSPT_View( 'settings-page' );

	}

}