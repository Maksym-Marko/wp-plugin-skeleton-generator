<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'Settings Page', 'mxspt-domain' ); ?></h1>

	<div class="mx-block_wrap">

		<form id="mxspt_form_update" class="mx-settings" method="post" action="">

			<h2>Default script</h2>
			<textarea name="mxspt_some_string" id="mxspt_some_string"><?php echo $data->some_field; ?></textarea>

			<p class="mx-submit_button_wrap">
				<input type="hidden" id="mxspt_wpnonce" name="mxspt_wpnonce" value="<?php echo wp_create_nonce( 'mxspt_nonce_request' ) ;?>" />
				<input class="button-primary" type="submit" name="mxspt_submit" value="Save" />
			</p>

		</form>

	</div>

</div>