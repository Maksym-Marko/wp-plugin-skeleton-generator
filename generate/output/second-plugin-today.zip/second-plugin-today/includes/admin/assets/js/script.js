jQuery( document ).ready( function( $ ) {

	$( '#mxspt_form_update' ).on( 'submit', function( e ){

		e.preventDefault();

		var nonce = $( this ).find( '#mxspt_wpnonce' ).val();

		var someString = $( '#mxspt_some_string' ).val();

		var data = {

			'action': 'mxspt_update',
			'nonce': nonce,
			'mxspt_some_string': someString

		};

		jQuery.post( mxmlb_admin_localize.ajaxurl, data, function( response ){

			// console.log( response );
			alert( 'Value updated.' );

		} );

	} );

} );