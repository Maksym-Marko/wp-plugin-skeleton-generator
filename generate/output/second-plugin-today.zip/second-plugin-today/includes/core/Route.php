<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXSPT_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXSPT_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxspt_get( ...$args )
	{

		return new MXSPT_Route_Registrar( ...$args );

	}
	
}