<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Error Handle calss
*/
class MXSPT_Display_Error
{

	/**
	* Error notice
	*/
	public $mxspt_error_notice = '';

	public function __construct( $mxspt_error_notice )
	{

		$this->mxspt_error_notice = $mxspt_error_notice;

	}

	public function mxspt_show_error()
	{
		
		add_action( 'admin_notices', function() { ?>

			<div class="notice notice-error is-dismissible">

			    <p><?php echo $this->mxspt_error_notice; ?></p>
			    
			</div>
		    
		<?php } );

	}

}