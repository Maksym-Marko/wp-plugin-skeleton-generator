<?php
/*
Plugin Name: second plugin today
Plugin URI: https://github.com/Maxim-us/wp-plugin-skeleton
Description: Brief description
Author: Marko Maksym
Version: 1.0
Author URI: https://github.com/Maxim-us
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Unique string - MXSPT
*/

/*
* Define MXSPT_PLUGIN_PATH
*
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\second-plugin-today\second-plugin-today.php
*/
if ( ! defined( 'MXSPT_PLUGIN_PATH' ) ) {

	define( 'MXSPT_PLUGIN_PATH', __FILE__ );

}

/*
* Define MXSPT_PLUGIN_URL
*
* Return http://my-domain.com/wp-content/plugins/second-plugin-today/
*/
if ( ! defined( 'MXSPT_PLUGIN_URL' ) ) {

	define( 'MXSPT_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

}

/*
* Define MXSPT_PLUGN_BASE_NAME
*
* 	Return second-plugin-today/second-plugin-today.php
*/
if ( ! defined( 'MXSPT_PLUGN_BASE_NAME' ) ) {

	define( 'MXSPT_PLUGN_BASE_NAME', plugin_basename( __FILE__ ) );

}

/*
* Define MXSPT_TABLE_SLUG
*/
if ( ! defined( 'MXSPT_TABLE_SLUG' ) ) {

	define( 'MXSPT_TABLE_SLUG', 'mxspt_table_slug' );

}

/*
* Define MXSPT_PLUGIN_ABS_PATH
* 
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\second-plugin-today/
*/
if ( ! defined( 'MXSPT_PLUGIN_ABS_PATH' ) ) {

	define( 'MXSPT_PLUGIN_ABS_PATH', dirname( MXSPT_PLUGIN_PATH ) . '/' );

}

/*
* Define MXSPT_PLUGIN_VERSION
*/
if ( ! defined( 'MXSPT_PLUGIN_VERSION' ) ) {

	// version
	define( 'MXSPT_PLUGIN_VERSION', time() ); // Must be replaced before production on for example '1.0'

}

/*
* Define MXSPT_MAIN_MENU_SLUG
*/
if ( ! defined( 'MXSPT_MAIN_MENU_SLUG' ) ) {

	// version
	define( 'MXSPT_MAIN_MENU_SLUG', 'mxspt-second-plugin-today-menu' );

}

/**
 * activation|deactivation
 */
require_once plugin_dir_path( __FILE__ ) . 'install.php';

/*
* Registration hooks
*/
// Activation
register_activation_hook( __FILE__, array( 'MXSPT_Basis_Plugin_Class', 'activate' ) );

// Deactivation
register_deactivation_hook( __FILE__, array( 'MXSPT_Basis_Plugin_Class', 'deactivate' ) );


/*
* Include the main MXSPTSecondPluginToday class
*/
if ( ! class_exists( 'MXSPTSecondPluginToday' ) ) {

	require_once plugin_dir_path( __FILE__ ) . 'includes/final-class.php';

	/*
	* Translate plugin
	*/
	add_action( 'plugins_loaded', 'mxspt_translate' );

	function mxspt_translate()
	{

		load_plugin_textdomain( 'mxspt-domain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

}