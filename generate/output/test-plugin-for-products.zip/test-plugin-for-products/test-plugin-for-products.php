<?php
/*
Plugin Name: test plugin for products
Plugin URI: https://github.com/Maxim-us/wp-plugin-skeleton
Description: Brief description
Author: Marko Maksym
Version: 1.0
Author URI: https://github.com/Maxim-us
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Unique string - MXTPFP
*/

/*
* Define MXTPFP_PLUGIN_PATH
*
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\test-plugin-for-products\test-plugin-for-products.php
*/
if ( ! defined( 'MXTPFP_PLUGIN_PATH' ) ) {

	define( 'MXTPFP_PLUGIN_PATH', __FILE__ );

}

/*
* Define MXTPFP_PLUGIN_URL
*
* Return http://my-domain.com/wp-content/plugins/test-plugin-for-products/
*/
if ( ! defined( 'MXTPFP_PLUGIN_URL' ) ) {

	define( 'MXTPFP_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

}

/*
* Define MXTPFP_PLUGN_BASE_NAME
*
* 	Return test-plugin-for-products/test-plugin-for-products.php
*/
if ( ! defined( 'MXTPFP_PLUGN_BASE_NAME' ) ) {

	define( 'MXTPFP_PLUGN_BASE_NAME', plugin_basename( __FILE__ ) );

}

/*
* Define MXTPFP_TABLE_SLUG
*/
if ( ! defined( 'MXTPFP_TABLE_SLUG' ) ) {

	define( 'MXTPFP_TABLE_SLUG', 'mxtpfp_mx_table' );

}

/*
* Define MXTPFP_PLUGIN_ABS_PATH
* 
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\test-plugin-for-products/
*/
if ( ! defined( 'MXTPFP_PLUGIN_ABS_PATH' ) ) {

	define( 'MXTPFP_PLUGIN_ABS_PATH', dirname( MXTPFP_PLUGIN_PATH ) . '/' );

}

/*
* Define MXTPFP_PLUGIN_VERSION
*/
if ( ! defined( 'MXTPFP_PLUGIN_VERSION' ) ) {

	// version
	define( 'MXTPFP_PLUGIN_VERSION', time() ); // Must be replaced before production on for example '1.0'

}

/*
* Define MXTPFP_MAIN_MENU_SLUG
*/
if ( ! defined( 'MXTPFP_MAIN_MENU_SLUG' ) ) {

	// version
	define( 'MXTPFP_MAIN_MENU_SLUG', 'mxtpfp-test-plugin-for-products-menu' );

}

/**
 * activation|deactivation
 */
require_once plugin_dir_path( __FILE__ ) . 'install.php';

/*
* Registration hooks
*/
// Activation
register_activation_hook( __FILE__, [ 'MXTPFP_Basis_Plugin_Class', 'activate' ] );

// Deactivation
register_deactivation_hook( __FILE__, [ 'MXTPFP_Basis_Plugin_Class', 'deactivate' ] );


/*
* Include the main MXTPFPTestPluginForProducts class
*/
if ( ! class_exists( 'MXTPFPTestPluginForProducts' ) ) {

	require_once plugin_dir_path( __FILE__ ) . 'includes/final-class.php';

	/*
	* Translate plugin
	*/
	add_action( 'plugins_loaded', 'mxtpfp_translate' );

	function mxtpfp_translate()
	{

		load_plugin_textdomain( 'mxtpfp-domain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

}