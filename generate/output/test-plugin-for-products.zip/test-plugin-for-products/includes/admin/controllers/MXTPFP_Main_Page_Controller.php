<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPFP_Main_Page_Controller extends MXTPFP_Controller
{
	
	public function index()
	{

		$model_inst = new MXTPFP_Main_Page_Model();

		$data = $model_inst->mxtpfp_get_row( NULL, 'product_id', 1 );

		return new MXTPFP_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXTPFP_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXTPFP_View( 'hidemenu-page' );

	}

	public function settings_menu_item_action()
	{

		return new MXTPFP_View( 'settings-page' );

	}

}