<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'This is a settings page', 'mxtpfp-domain' ); ?></h1>

</div>