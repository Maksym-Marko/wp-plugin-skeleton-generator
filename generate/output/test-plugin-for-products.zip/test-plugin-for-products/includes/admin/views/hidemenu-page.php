<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'This page doesn\'t appear in the list of menu items', 'mxtpfp-domain' ); ?></h1>

</div>