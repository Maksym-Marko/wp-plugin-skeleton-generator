<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPFP_Enqueue_Scripts
{

	/*
	* MXTPFP_Enqueue_Scripts
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxtpfp_register()
	{

		// register scripts and styles
		add_action( 'admin_enqueue_scripts', [ 'MXTPFP_Enqueue_Scripts', 'mxtpfp_enqueue' ] );

	}

		public static function mxtpfp_enqueue()
		{

			wp_enqueue_style( 'mxtpfp_font_awesome', MXTPFP_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );

			wp_enqueue_style( 'mxtpfp_admin_style', MXTPFP_PLUGIN_URL . 'includes/admin/assets/css/style.css', [ 'mxtpfp_font_awesome' ], MXTPFP_PLUGIN_VERSION, 'all' );

			wp_enqueue_script( 'mxtpfp_admin_script', MXTPFP_PLUGIN_URL . 'includes/admin/assets/js/script.js', [ 'jquery' ], MXTPFP_PLUGIN_VERSION, false );

			wp_localize_script( 'mxtpfp_admin_script', 'mxtpfp_admin_localize', [

				'ajaxurl' 			=> admin_url( 'admin-ajax.php' )

			] );

		}

}