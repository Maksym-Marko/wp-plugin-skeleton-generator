jQuery(document).ready(function ($) {

	$('#mxtpfp_form_update').on('submit', function (e) {

		e.preventDefault();

		var nonce = $(this).find('#mxtpfp_wpnonce').val();

		var name = $('#mxtpfp_mx_name').val();

		var description = $('#mxtpfp_mx_description').val();

		var data = {

			'action': 'mxtpfp_update',
			'nonce': nonce,
			'name': name,
			'description': description

		};

		jQuery.post(mxtpfp_admin_localize.ajaxurl, data, function (response) {

			// console.log( response );
			alert('Value updated.');

		});

	});

});