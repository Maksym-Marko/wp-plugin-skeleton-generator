<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPFP_FrontEnd_Main
{

	/*
	* MXTPFP_FrontEnd_Main constructor
	*/
	public function __construct()
	{

	}

	/*
	* Additional classes
	*/
	public function mxtpfp_additional_classes()
	{

		// enqueue_scripts class
		mxtpfp_require_class_file_frontend( 'enqueue-scripts.php' );

		MXTPFP_Enqueue_Scripts_Frontend::mxtpfp_register();

	}

}

// Initialize
$initialize_frontend_class = new MXTPFP_FrontEnd_Main();

// include classes
$initialize_frontend_class->mxtpfp_additional_classes();