<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTPFP_Enqueue_Scripts_Frontend
{

	/*
	* MXTPFP_Enqueue_Scripts_Frontend
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxtpfp_register()
	{

		// register scripts and styles
		add_action( 'wp_enqueue_scripts', [ 'MXTPFP_Enqueue_Scripts_Frontend', 'mxtpfp_enqueue' ] );

	}

		public static function mxtpfp_enqueue()
		{

			wp_enqueue_style( 'mxtpfp_font_awesome', MXTPFP_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );
			
			wp_enqueue_style( 'mxtpfp_style', MXTPFP_PLUGIN_URL . 'includes/frontend/assets/css/style.css', [ 'mxtpfp_font_awesome' ], MXTPFP_PLUGIN_VERSION, 'all' );
			
			wp_enqueue_script( 'mxtpfp_script', MXTPFP_PLUGIN_URL . 'includes/frontend/assets/js/script.js', [ 'jquery' ], MXTPFP_PLUGIN_VERSION, false );
		
		}

}