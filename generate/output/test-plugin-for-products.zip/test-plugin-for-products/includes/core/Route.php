<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXTPFP_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXTPFP_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxtpfp_get( ...$args )
	{

		return new MXTPFP_Route_Registrar( ...$args );

	}
	
}