<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXTP_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXTP_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxtp_get( ...$args )
	{

		return new MXTP_Route_Registrar( ...$args );

	}
	
}