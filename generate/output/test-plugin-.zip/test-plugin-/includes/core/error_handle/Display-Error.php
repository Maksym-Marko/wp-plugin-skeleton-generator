<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Error Handle calss
*/
class MXTP_Display_Error
{

	/**
	* Error notice
	*/
	public $mxtp_error_notice = '';

	public function __construct( $mxtp_error_notice )
	{

		$this->mxtp_error_notice = $mxtp_error_notice;

	}

	public function mxtp_show_error()
	{
		
		add_action( 'admin_notices', function() { ?>

			<div class="notice notice-error is-dismissible">

			    <p><?php echo esc_attr( $this->mxtp_error_notice ); ?></p>
			    
			</div>
		    
		<?php } );

	}

}