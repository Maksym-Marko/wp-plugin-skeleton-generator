<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'This is settings page.', 'mxtp-domain' ); ?></h1>

</div>