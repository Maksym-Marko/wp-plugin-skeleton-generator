<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTP_Main_Page_Controller extends MXTP_Controller
{
	
	public function index()
	{

		$model_inst = new MXTP_Main_Page_Model();

		$data = $model_inst->mxtp_get_row( NULL, 'product_id', 1 );

		return new MXTP_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXTP_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXTP_View( 'hidemenu-page' );

	}

	public function settings_menu_item_action()
	{

		return new MXTP_View( 'settings-page' );

	}

}