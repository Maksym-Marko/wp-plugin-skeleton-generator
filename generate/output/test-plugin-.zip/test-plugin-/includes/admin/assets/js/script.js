jQuery( document ).ready( function( $ ) {

	$( '#mxtp_form_update' ).on( 'submit', function( e ){

		e.preventDefault();

		var nonce = $( this ).find( '#mxtp_wpnonce' ).val();

		var someString = $( '#mxtp_some_string' ).val();

		var data = {

			'action': 'mxtp_update',
			'nonce': nonce,
			'mxtp_some_string': someString

		};

		jQuery.post( mxtp_admin_localize.ajaxurl, data, function( response ){

			// console.log( response );
			alert( 'Value updated.' );

		} );

	} );

} );