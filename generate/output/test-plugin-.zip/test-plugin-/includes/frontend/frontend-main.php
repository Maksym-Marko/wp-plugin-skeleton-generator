<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXTP_FrontEnd_Main
{

	/*
	* MXTP_FrontEnd_Main constructor
	*/
	public function __construct()
	{

	}

	/*
	* Additional classes
	*/
	public function mxtp_additional_classes()
	{

		// enqueue_scripts class
		mxtp_require_class_file_frontend( 'enqueue-scripts.php' );

		MXTP_Enqueue_Scripts_Frontend::mxtp_register();

	}

}

// Initialize
$initialize_admin_class = new MXTP_FrontEnd_Main();

// include classes
$initialize_admin_class->mxtp_additional_classes();