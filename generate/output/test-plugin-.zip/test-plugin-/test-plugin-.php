<?php
/*
Plugin Name: test plugin 
Plugin URI: https://github.com/Maxim-us/wp-plugin-skeleton
Description: Brief description
Author: Marko Maksym
Version: 1.0
Author URI: https://github.com/Maxim-us
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Unique string - MXTP
*/

/*
* Define MXTP_PLUGIN_PATH
*
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\test-plugin-\test-plugin-.php
*/
if ( ! defined( 'MXTP_PLUGIN_PATH' ) ) {

	define( 'MXTP_PLUGIN_PATH', __FILE__ );

}

/*
* Define MXTP_PLUGIN_URL
*
* Return http://my-domain.com/wp-content/plugins/test-plugin-/
*/
if ( ! defined( 'MXTP_PLUGIN_URL' ) ) {

	define( 'MXTP_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

}

/*
* Define MXTP_PLUGN_BASE_NAME
*
* 	Return test-plugin-/test-plugin-.php
*/
if ( ! defined( 'MXTP_PLUGN_BASE_NAME' ) ) {

	define( 'MXTP_PLUGN_BASE_NAME', plugin_basename( __FILE__ ) );

}

/*
* Define MXTP_TABLE_SLUG
*/
if ( ! defined( 'MXTP_TABLE_SLUG' ) ) {

	define( 'MXTP_TABLE_SLUG', 'mxtp_mx_table' );

}

/*
* Define MXTP_PLUGIN_ABS_PATH
* 
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\test-plugin-/
*/
if ( ! defined( 'MXTP_PLUGIN_ABS_PATH' ) ) {

	define( 'MXTP_PLUGIN_ABS_PATH', dirname( MXTP_PLUGIN_PATH ) . '/' );

}

/*
* Define MXTP_PLUGIN_VERSION
*/
if ( ! defined( 'MXTP_PLUGIN_VERSION' ) ) {

	// version
	define( 'MXTP_PLUGIN_VERSION', time() ); // Must be replaced before production on for example '1.0'

}

/*
* Define MXTP_MAIN_MENU_SLUG
*/
if ( ! defined( 'MXTP_MAIN_MENU_SLUG' ) ) {

	// version
	define( 'MXTP_MAIN_MENU_SLUG', 'mxtp-test-plugin--menu' );

}

/**
 * activation|deactivation
 */
require_once plugin_dir_path( __FILE__ ) . 'install.php';

/*
* Registration hooks
*/
// Activation
register_activation_hook( __FILE__, [ 'MXTP_Basis_Plugin_Class', 'activate' ] );

// Deactivation
register_deactivation_hook( __FILE__, [ 'MXTP_Basis_Plugin_Class', 'deactivate' ] );


/*
* Include the main MXTPTestPlugin class
*/
if ( ! class_exists( 'MXTPTestPlugin' ) ) {

	require_once plugin_dir_path( __FILE__ ) . 'includes/final-class.php';

	/*
	* Translate plugin
	*/
	add_action( 'plugins_loaded', 'mxtp_translate' );

	function mxtp_translate()
	{

		load_plugin_textdomain( 'mxtp-domain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

}