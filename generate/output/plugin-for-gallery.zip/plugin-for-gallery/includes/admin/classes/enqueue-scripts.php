<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXPFG_Enqueue_Scripts
{

	/*
	* MXPFG_Enqueue_Scripts
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxpfg_register()
	{

		// register scripts and styles
		add_action( 'admin_enqueue_scripts', [ 'MXPFG_Enqueue_Scripts', 'mxpfg_enqueue' ] );

	}

		public static function mxpfg_enqueue()
		{

			wp_enqueue_style( 'mxpfg_font_awesome', MXPFG_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );

			wp_enqueue_style( 'mxpfg_admin_style', MXPFG_PLUGIN_URL . 'includes/admin/assets/css/style.css', [ 'mxpfg_font_awesome' ], MXPFG_PLUGIN_VERSION, 'all' );

			wp_enqueue_script( 'mxpfg_admin_script', MXPFG_PLUGIN_URL . 'includes/admin/assets/js/script.js', [ 'jquery' ], MXPFG_PLUGIN_VERSION, false );

			wp_localize_script( 'mxpfg_admin_script', 'mxpfg_admin_localize', [

				'ajaxurl' 			=> admin_url( 'admin-ajax.php' )

			] );

		}

}