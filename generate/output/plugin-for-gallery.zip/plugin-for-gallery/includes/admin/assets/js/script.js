jQuery( document ).ready( function( $ ) {

	$( '#mxpfg_form_update' ).on( 'submit', function( e ){

		e.preventDefault();

		var nonce = $( this ).find( '#mxpfg_wpnonce' ).val();

		var someString = $( '#mxpfg_some_string' ).val();

		var data = {

			'action': 'mxpfg_update',
			'nonce': nonce,
			'mxpfg_some_string': someString

		};

		jQuery.post( mxpfg_admin_localize.ajaxurl, data, function( response ){

			// console.log( response );
			alert( 'Value updated.' );

		} );

	} );

} );