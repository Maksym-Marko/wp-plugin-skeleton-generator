<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXPFG_Main_Page_Controller extends MXPFG_Controller
{
	
	public function index()
	{

		$model_inst = new MXPFG_Main_Page_Model();

		$data = $model_inst->mxpfg_get_row( NULL, 'product_id', 1 );

		return new MXPFG_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXPFG_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXPFG_View( 'hidemenu-page' );

	}

	public function settings_menu_item_action()
	{

		return new MXPFG_View( 'settings-page' );

	}

}