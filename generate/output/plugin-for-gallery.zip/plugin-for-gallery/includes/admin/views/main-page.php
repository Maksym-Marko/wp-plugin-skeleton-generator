<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'Settings Page', 'mxpfg-domain' ); ?></h1>

	<div class="mx-block_wrap">

		<form id="mxpfg_form_update" class="mx-settings" method="post" action="">

			<h2>Default script</h2>
			<textarea name="mxpfg_some_string" id="mxpfg_some_string"><?php echo $data->mx_name; ?></textarea>

			<p class="mx-submit_button_wrap">
				<input type="hidden" id="mxpfg_wpnonce" name="mxpfg_wpnonce" value="<?php echo wp_create_nonce( 'mxpfg_nonce_request' ) ;?>" />
				<input class="button-primary" type="submit" name="mxpfg_submit" value="Save" />
			</p>

		</form>

	</div>

</div>