<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXPFG_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXPFG_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxpfg_get( ...$args )
	{

		return new MXPFG_Route_Registrar( ...$args );

	}
	
}