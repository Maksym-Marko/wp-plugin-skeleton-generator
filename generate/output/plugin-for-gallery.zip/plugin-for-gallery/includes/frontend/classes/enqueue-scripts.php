<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXPFG_Enqueue_Scripts_Frontend
{

	/*
	* MXPFG_Enqueue_Scripts_Frontend
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxpfg_register()
	{

		// register scripts and styles
		add_action( 'wp_enqueue_scripts', [ 'MXPFG_Enqueue_Scripts_Frontend', 'mxpfg_enqueue' ] );

	}

		public static function mxpfg_enqueue()
		{

			wp_enqueue_style( 'mxpfg_font_awesome', MXPFG_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );
			
			wp_enqueue_style( 'mxpfg_style', MXPFG_PLUGIN_URL . 'includes/frontend/assets/css/style.css', [ 'mxpfg_font_awesome' ], MXPFG_PLUGIN_VERSION, 'all' );
			
			wp_enqueue_script( 'mxpfg_script', MXPFG_PLUGIN_URL . 'includes/frontend/assets/js/script.js', [ 'jquery' ], MXPFG_PLUGIN_VERSION, false );
		
		}

}