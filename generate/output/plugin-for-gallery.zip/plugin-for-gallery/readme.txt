=== plugin for gallery ===
Contributors: markomaksym
Tags: create table, create CPT, add metaboxes
Requires at least: 4.9
Tested up to: 5.8
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
	WP Plugin Skeleton Generator Version: 			4.0
	WP Plugin Skeleton Generator Author: 			Maksym Marko
	WP Plugin Skeleton Generator Author Website:	https://markomaksym.com.ua/

Brief description

== Description ==

Long description

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'WP Plugin Skeleton'
3. Activate the plugin from your Plugins page.
4. ...

= From WordPress.org =

1. Download 'WP Plugin Skeleton'.
2. Upload the 'WP Plugin Skeleton' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate 'WP Plugin Skeleton' from your Plugins page.
4. ...

== Screenshots ==

1. Click the button
2. Item moved upwards
3. Click the button again
4. ...

== Changelog ==

= 1.0 =
* Your first commit