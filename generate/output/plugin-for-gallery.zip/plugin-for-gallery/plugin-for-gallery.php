<?php
/*
Plugin Name: plugin for gallery
Plugin URI: https://github.com/Maxim-us/wp-plugin-skeleton
Description: Brief description
Author: Marko Maksym
Version: 1.0
Author URI: https://github.com/Maxim-us
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Unique string - MXPFG
*/

/*
* Define MXPFG_PLUGIN_PATH
*
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\plugin-for-gallery\plugin-for-gallery.php
*/
if ( ! defined( 'MXPFG_PLUGIN_PATH' ) ) {

	define( 'MXPFG_PLUGIN_PATH', __FILE__ );

}

/*
* Define MXPFG_PLUGIN_URL
*
* Return http://my-domain.com/wp-content/plugins/plugin-for-gallery/
*/
if ( ! defined( 'MXPFG_PLUGIN_URL' ) ) {

	define( 'MXPFG_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

}

/*
* Define MXPFG_PLUGN_BASE_NAME
*
* 	Return plugin-for-gallery/plugin-for-gallery.php
*/
if ( ! defined( 'MXPFG_PLUGN_BASE_NAME' ) ) {

	define( 'MXPFG_PLUGN_BASE_NAME', plugin_basename( __FILE__ ) );

}

/*
* Define MXPFG_TABLE_SLUG
*/
if ( ! defined( 'MXPFG_TABLE_SLUG' ) ) {

	define( 'MXPFG_TABLE_SLUG', 'mxpfg_mx_table' );

}

/*
* Define MXPFG_PLUGIN_ABS_PATH
* 
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\plugin-for-gallery/
*/
if ( ! defined( 'MXPFG_PLUGIN_ABS_PATH' ) ) {

	define( 'MXPFG_PLUGIN_ABS_PATH', dirname( MXPFG_PLUGIN_PATH ) . '/' );

}

/*
* Define MXPFG_PLUGIN_VERSION
*/
if ( ! defined( 'MXPFG_PLUGIN_VERSION' ) ) {

	// version
	define( 'MXPFG_PLUGIN_VERSION', time() ); // Must be replaced before production on for example '1.0'

}

/*
* Define MXPFG_MAIN_MENU_SLUG
*/
if ( ! defined( 'MXPFG_MAIN_MENU_SLUG' ) ) {

	// version
	define( 'MXPFG_MAIN_MENU_SLUG', 'mxpfg-plugin-for-gallery-menu' );

}

/**
 * activation|deactivation
 */
require_once plugin_dir_path( __FILE__ ) . 'install.php';

/*
* Registration hooks
*/
// Activation
register_activation_hook( __FILE__, [ 'MXPFG_Basis_Plugin_Class', 'activate' ] );

// Deactivation
register_deactivation_hook( __FILE__, [ 'MXPFG_Basis_Plugin_Class', 'deactivate' ] );


/*
* Include the main MXPFGPluginForGallery class
*/
if ( ! class_exists( 'MXPFGPluginForGallery' ) ) {

	require_once plugin_dir_path( __FILE__ ) . 'includes/final-class.php';

	/*
	* Translate plugin
	*/
	add_action( 'plugins_loaded', 'mxpfg_translate' );

	function mxpfg_translate()
	{

		load_plugin_textdomain( 'mxpfg-domain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

}