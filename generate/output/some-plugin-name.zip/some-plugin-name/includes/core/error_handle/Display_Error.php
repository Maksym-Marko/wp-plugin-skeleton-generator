<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Error Handle calss
*/
class MXSPN_Display_Error
{

	/**
	* Error notice
	*/
	public $mxspn_error_notice = '';

	public function __construct( $mxspn_error_notice )
	{

		$this->mxspn_error_notice = $mxspn_error_notice;

	}

	public function mxspn_show_error()
	{
		add_action( 'admin_notices', function() { ?>

			<div class="notice notice-error is-dismissible">

			    <p><?php echo esc_attr( $this->mxspn_error_notice ); ?></p>
			    
			</div>
		    
		<?php } );
	}

}