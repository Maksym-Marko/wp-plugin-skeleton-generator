<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// require Route-Registrar.php
require_once MXSPN_PLUGIN_ABS_PATH . 'includes/core/Route-Registrar.php';

/*
* Routes class
*/
class MXSPN_Route
{

	public function __construct()
	{
		// ...
	}
	
	public static function mxspn_get( ...$args )
	{

		return new MXSPN_Route_Registrar( ...$args );

	}
	
}