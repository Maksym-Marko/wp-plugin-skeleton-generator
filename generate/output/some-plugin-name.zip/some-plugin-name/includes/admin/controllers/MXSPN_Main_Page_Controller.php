<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXSPN_Main_Page_Controller extends MXSPN_Controller
{
	
	public function index()
	{

		$model_inst = new MXSPN_Main_Page_Model();

		$data = $model_inst->mxspn_get_row( NULL, 'product_id', 1 );

		return new MXSPN_View( 'main-page', $data );

	}

	public function submenu()
	{

		return new MXSPN_View( 'sub-page' );

	}

	public function hidemenu()
	{

		return new MXSPN_View( 'hidemenu-page' );

	}

	public function settings_menu_item_action()
	{

		return new MXSPN_View( 'settings-page' );

	}

}