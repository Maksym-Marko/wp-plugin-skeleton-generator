jQuery( document ).ready( function( $ ) {

	$( '#mxspn_form_update' ).on( 'submit', function( e ){

		e.preventDefault();

		var nonce = $( this ).find( '#mxspn_wpnonce' ).val();

		var someString = $( '#mxspn_some_string' ).val();

		var data = {

			'action': 'mxspn_update',
			'nonce': nonce,
			'mxspn_some_string': someString

		};

		jQuery.post( mxspn_admin_localize.ajaxurl, data, function( response ){

			// console.log( response );
			alert( 'Value updated.' );

		} );

	} );

} );