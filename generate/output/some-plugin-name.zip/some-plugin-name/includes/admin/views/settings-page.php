<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'This is settings page.', 'mxspn-domain' ); ?></h1>

</div>