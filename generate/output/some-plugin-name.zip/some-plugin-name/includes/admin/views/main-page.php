<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'Settings Page', 'mxspn-domain' ); ?></h1>

	<div class="mx-block_wrap">

		<form id="mxspn_form_update" class="mx-settings" method="post" action="">

			<h2>Default script</h2>
			<textarea name="mxspn_some_string" id="mxspn_some_string"><?php echo $data->mx_name; ?></textarea>

			<p class="mx-submit_button_wrap">
				<input type="hidden" id="mxspn_wpnonce" name="mxspn_wpnonce" value="<?php echo wp_create_nonce( 'mxspn_nonce_request' ) ;?>" />
				<input class="button-primary" type="submit" name="mxspn_submit" value="Save" />
			</p>

		</form>

	</div>

</div>