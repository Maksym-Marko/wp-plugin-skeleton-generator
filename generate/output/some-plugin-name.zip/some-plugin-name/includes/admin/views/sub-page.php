<div class="mx-main-page-text-wrap">
	
	<h1><?php echo __( 'Sub menu page', 'mxspn-domain' ); ?></h1>

	<a href="<?php echo admin_url(); ?>admin.php?page=hide_menu">This link doesn't appear in the list of menu items.</a>

</div>