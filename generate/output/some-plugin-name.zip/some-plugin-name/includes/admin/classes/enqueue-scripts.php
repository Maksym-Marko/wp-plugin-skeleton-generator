<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class MXSPN_Enqueue_Scripts
{

	/*
	* MXSPN_Enqueue_Scripts
	*/
	public function __construct()
	{

	}

	/*
	* Registration of styles and scripts
	*/
	public static function mxspn_register()
	{

		// register scripts and styles
		add_action( 'admin_enqueue_scripts', [ 'MXSPN_Enqueue_Scripts', 'mxspn_enqueue' ] );

	}

		public static function mxspn_enqueue()
		{

			wp_enqueue_style( 'mxspn_font_awesome', MXSPN_PLUGIN_URL . 'assets/font-awesome-4.6.3/css/font-awesome.min.css' );

			wp_enqueue_style( 'mxspn_admin_style', MXSPN_PLUGIN_URL . 'includes/admin/assets/css/style.css', [ 'mxspn_font_awesome' ], MXSPN_PLUGIN_VERSION, 'all' );

			wp_enqueue_script( 'mxspn_admin_script', MXSPN_PLUGIN_URL . 'includes/admin/assets/js/script.js', [ 'jquery' ], MXSPN_PLUGIN_VERSION, false );

			wp_localize_script( 'mxspn_admin_script', 'mxspn_admin_localize', [

				'ajaxurl' 			=> admin_url( 'admin-ajax.php' )

			] );

		}

}