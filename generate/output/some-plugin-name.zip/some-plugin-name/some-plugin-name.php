<?php
/*
Plugin Name: some plugin name
Plugin URI: https://github.com/Maxim-us/wp-plugin-skeleton
Description: Brief description
Author: Marko Maksym
Version: 1.0
Author URI: https://github.com/Maxim-us
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/*
* Unique string - MXSPN
*/

/*
* Define MXSPN_PLUGIN_PATH
*
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\some-plugin-name\some-plugin-name.php
*/
if ( ! defined( 'MXSPN_PLUGIN_PATH' ) ) {

	define( 'MXSPN_PLUGIN_PATH', __FILE__ );

}

/*
* Define MXSPN_PLUGIN_URL
*
* Return http://my-domain.com/wp-content/plugins/some-plugin-name/
*/
if ( ! defined( 'MXSPN_PLUGIN_URL' ) ) {

	define( 'MXSPN_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

}

/*
* Define MXSPN_PLUGN_BASE_NAME
*
* 	Return some-plugin-name/some-plugin-name.php
*/
if ( ! defined( 'MXSPN_PLUGN_BASE_NAME' ) ) {

	define( 'MXSPN_PLUGN_BASE_NAME', plugin_basename( __FILE__ ) );

}

/*
* Define MXSPN_TABLE_SLUG
*/
if ( ! defined( 'MXSPN_TABLE_SLUG' ) ) {

	define( 'MXSPN_TABLE_SLUG', 'mxspn_mx_table' );

}

/*
* Define MXSPN_PLUGIN_ABS_PATH
* 
* E:\OpenServer\domains\my-domain.com\wp-content\plugins\some-plugin-name/
*/
if ( ! defined( 'MXSPN_PLUGIN_ABS_PATH' ) ) {

	define( 'MXSPN_PLUGIN_ABS_PATH', dirname( MXSPN_PLUGIN_PATH ) . '/' );

}

/*
* Define MXSPN_PLUGIN_VERSION
*/
if ( ! defined( 'MXSPN_PLUGIN_VERSION' ) ) {

	// version
	define( 'MXSPN_PLUGIN_VERSION', time() ); // Must be replaced before production on for example '1.0'

}

/*
* Define MXSPN_MAIN_MENU_SLUG
*/
if ( ! defined( 'MXSPN_MAIN_MENU_SLUG' ) ) {

	// version
	define( 'MXSPN_MAIN_MENU_SLUG', 'mxspn-some-plugin-name-menu' );

}

/**
 * activation|deactivation
 */
require_once plugin_dir_path( __FILE__ ) . 'install.php';

/*
* Registration hooks
*/
// Activation
register_activation_hook( __FILE__, [ 'MXSPN_Basis_Plugin_Class', 'activate' ] );

// Deactivation
register_deactivation_hook( __FILE__, [ 'MXSPN_Basis_Plugin_Class', 'deactivate' ] );


/*
* Include the main MXSPNSomePluginName class
*/
if ( ! class_exists( 'MXSPNSomePluginName' ) ) {

	require_once plugin_dir_path( __FILE__ ) . 'includes/final-class.php';

	/*
	* Translate plugin
	*/
	add_action( 'plugins_loaded', 'mxspn_translate' );

	function mxspn_translate()
	{

		load_plugin_textdomain( 'mxspn-domain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

}